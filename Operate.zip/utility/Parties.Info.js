const Parties =[
    {
        FullName: "Pakistan Tehreek-e-Insaf",
        Party:"PTI",
        Founder :"Imran Khan",
        Founded:  "1996"
    },
    {
        FullName: "Pakistan Muslim League (N)",
        Party:"PMLN",
        Founder :"Nawaz Sharif",
        Founded:  "1993"
    },
    {
        FullName: "Pakistan People's Party",
        Party:"PPP",
        Founder :"Zulfikar Ali Bhutto",
        Founded:  "1967"
    },
    {
        FullName: "Muttahida Qaumi Movement",
        Party:"MQM",
        Founder :"Altaf Hussain",
        Founded:  "1984"
    },
    {
        FullName: "Jamiat Ulema-e-Islam",
        Party:"JI",
        Founder :"Jamiat Ulema-e-Hind",
        Founded:  "1919"
    },
    
]
module.exports = Parties;